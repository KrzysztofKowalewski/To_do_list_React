import './App.css';
import Wpis from './components/Wpis';

function App() {
  return <Wpis/>;
}

export default App;
