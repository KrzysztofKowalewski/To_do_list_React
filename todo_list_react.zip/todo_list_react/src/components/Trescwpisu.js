import React from "react";

const Trescwpisu = props => {
    return (
    <div key = {props.wpis.id}>
        <h2>{props.wpis.tytul}</h2>
    </div>
    )
}

export default Trescwpisu